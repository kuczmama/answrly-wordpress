=== Answrly ===
Contributors: answrly
Tags: answrly, answers, answer, question, monetize blog, make money
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Answrly lets you charge your users for your knowlege.  Don't give your advice away for free.

== Description ==

Answrly lets you charge your users for your knowlege.  Don't give your advice away for free.

**How it works**

1. Create an answrly account (<a href='https://www.answrly.com/expert_signup'>Account Signup</a>)
2. Decide how much you want to charge for a question
3. Answrly will put a textbox on your site.  
4. Your user will ask you a question in the textbox and then be automatically directed to answrly.  There they will enter their credit card details.
5. You receive an email letting you know that you have a new question.  
6. Click the link in the email to the question so you can answer it.
7. Get paid in your stripe account

It doesn't matter whether it is for $1 dollar or $10,000 dollars.  All you need to worry about is answering your users questions.  Answrly handles the rest.  


**Why Answrly?**

Before answrly there wasn't too many ways you could monetize your website.  There was advertising, affiliate marketing, consulting, selling a product, and not much else. This allows you to help people with questions not big enough for a full time consulting gig.    Now, you can sell your expertise and charge customers for just one question or piece of advice.


**Pricing**

Answrly will only charge 80 cents + 16% (<a href='https://www.answrly.com/pricing'>Pricing Details</a>). 

== Installation ==

To get started:

1. Click the "Activate" link
2. Sign up as an expert at <a href="https://www.answrly.com/expert_signup">answrly.com</a>
3. Answrly will appear as an available widget
4. Place Answrly Widget at desired location ie. Sidebar, Content Bottom, etc.
5. In the Answrly Widget settings enter your answrly username and password to link your acount to wordpress
6. Customize Widget Options if desired (pricing, widget title, etc.)
7. You're ready to start making money with your website

== Frequently Asked Questions ==

= How do I get paid? = 

You need to create a Stripe account. Payments will go into your account 24-48 hours after you answer a question.


= How much can I get paid? = 

There is no limit to how much you can earn. You can charge as much or as little as you want to answer a question.  Answrly will deduct a small amount from each question.  There is no setup cost or hidden fees. To protect the users of the site their card will not be charged until you actually give them an answer.


= How much does it cost? =

It costs you nothing to use answrly.  Answrly only takes out a small percentage from what your users pay.  Answrly will only deduct 80 cents + 16%.  So if you charge your user $100 dollars for an answr you will have $83.20 deposited into your account once you answer it.

== Screenshots ==

1. assets/screenshot-1.png
2. assets/screenshot-2.png
3. assets/screenshot-3.png
4. assets/screenshot-4.png

== ChangeLog ==
No changes have been made... Yet.

== Upgrade Notice ==
No upgrades have been made... Yet.